===========================================================================================================================================
Quake Emblem
a Quake 2 mod created by Joey Yannuzzi

INSTALLATION and RUNNING
------------------------
-unzip the Q2Mod folder in your Quake 2 game's files
-Run Quake 2 through your desired launcher, or through the executable
-open up the in-game command line and type "set game Q2Mod"
-Exit out of the command line and start a single player game

CONTROLS
--------
-F1: in-game help menu (can also use the command "help")
-F: spawn player controlled units (can also use the command "spawn"
-M: upgrade a player controlled unit's weapon (must have the unit selected and have enough gold) (can also use the command "forge")
-Other controls handled by Quake 2's defaults

PLAYING
-------
-Once loaded in, press F to spawn in the player controlled units (maximum of five units)
-Move the units by shooting them (to select them) and walk where you want the unit to head
-The unit will find the best path towards the destination and walk there until it runs out of movement
-While a unit is selected, the player can choose to attack an enemy by shooting it to select it (if in range) or upgrade the unit's weapon
-Once the player is done commanding a unit, shoot to deselect
-After every unit moves, the enemy will move their units
-The player cannot do any actions while it is the enemy's turn (you can move around to get out of the way of enemies)

OBJECTIVE
---------
-Destroy all the enemies
-Dont't let your Lord die
===========================================================================================================================================